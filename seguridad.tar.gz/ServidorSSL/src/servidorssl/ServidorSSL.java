/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidorssl;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;

/**
 *
 * @author jaorr
 */
public class ServidorSSL {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        PrintStream p;
        try {
            //System.setProperty("javax.net.ssl.keyStore","/home/jaorr/Descargas/certificados2/keystore.jks");
            System.setProperty("javax.net.ssl.keyStore","/home/jaorr/almacenes/probando/keystore.jks");
            //System.setProperty("javax.net.ssl.keyStore","/home/jaorr/SSL/serverTrustedCerts.jks");

            System.setProperty("javax.net.ssl.keyStorePassword","123456");
            //System.setProperty("javax.net.ssl.keyStorePassword","serverpass");
            System.setProperty("javax.net.debug", "all");
            SSLServerSocketFactory sslServerSocketFactory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
            
            SSLServerSocket sslServerSocket =(SSLServerSocket) sslServerSocketFactory.createServerSocket(8443);
            sslServerSocket.setNeedClientAuth(false);
           
            System.out.println("esperando conexiones...");
            SSLSocket sslSocket = (SSLSocket) sslServerSocket.accept();
            p = new PrintStream(sslSocket.getOutputStream());
            InputStream inputstream = sslSocket.getInputStream();
            InputStreamReader inputstreamreader = new InputStreamReader(inputstream);
            BufferedReader bufferedreader = new BufferedReader(inputstreamreader); 
            String string = null;
            
            //SSLSession sesion = sslSocket.getSession();
            //System.out.println("Host: "+sesion.getPeerHost());
            
            while ((string = bufferedreader.readLine()) != null) {
                System.out.println(string);
                System.out.flush();
                Thread.currentThread().sleep(1000);
                p.println(string);
            }
        }
        catch (Exception exception)
        {
        exception.printStackTrace();
        }
    }
    
}
