/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientessl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import static java.lang.System.in;
import java.util.Scanner;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 *
 * @author jaorr
 */
public class ClienteSSL {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        try {
            String dirip;  
            //System.setProperty("javax.net.ssl.trustStore","/home/jaorr/Descargas/certificados2/cacerts.jks");
            System.setProperty("javax.net.ssl.trustStore","/home/jaorr/almacenes/probando/cacerts.jks");
            System.setProperty("javax.net.ssl.trustStorePassword", "123456");
            //System.setProperty("javax.net.ssl.trustStore","clientTrustedCerts.jks");

            System.setProperty("javax.net.debug", "all");
            
            InputStreamReader flujo = new InputStreamReader(System.in);
            BufferedReader teclado = new BufferedReader(flujo);
            System.out.println("Direccion IP: ");
            dirip=teclado.readLine();
            System.out.print("Puerto:" );
            Scanner sc =new Scanner(System.in);
            String pto= sc.nextLine();
            int ptoint= Integer.parseInt(pto);
            
            SSLSocketFactory sslSocketFactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
            SSLSocket sslSocket = (SSLSocket) sslSocketFactory.createSocket(dirip, ptoint);
            
            System.out.println("creando socket");
            InputStream inputstream = System.in;
            InputStreamReader inputstreamreader = new InputStreamReader(inputstream);
            BufferedReader bufferedreader = new BufferedReader(inputstreamreader);
            OutputStream outputStream = sslSocket.getOutputStream();
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
            BufferedWriter bufferedwriter = new BufferedWriter(outputStreamWriter);
            String string = null;
            InputStream inputStream2 = sslSocket.getInputStream(); 
            InputStreamReader inputStreamReader2 = new InputStreamReader(inputStream2);
            BufferedReader bufferedreader2 = new BufferedReader(inputStreamReader2);
            while (!(string = bufferedreader.readLine()).equals("")) {
                bufferedwriter.write(string + '\n');
                bufferedwriter.flush();
                System.out.println(bufferedreader2.readLine() );
            }
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
        }
    }
    
}
